<?php

return [
    'except'                  => [
        'password',
        'password_confirmation',
    ],

    // If this value set to `true` inline listeners will be escaped, otherwise they will be removed.
    'escape_inline_listeners' => false,
];
